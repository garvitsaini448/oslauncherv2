package com.example.oslauncher

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

/** Windows-11-style light palette. */
object Win {
    val Ink = Color(0xFF1B1F27)
    val InkDim = Color(0xFF515B69)
    val InkFaint = Color(0xFF7D8896)
    val Sheet = Color(0xF7F4F7FB)          // dialogs / drawer
    val Wash = Brush.verticalGradient(listOf(Color(0x66FFFFFF), Color(0x99E9EFF8)))
}

/**
 * "Acrylic" look: translucent white gradient + soft light border + optional colour tint.
 * (True backdrop blur needs Android 12+; this gradient version is GPU-cheap and works on the A20s.)
 */
fun Modifier.acrylic(
    shape: Shape = RoundedCornerShape(18.dp),
    strong: Boolean = false,
    tint: Color = Color.Transparent
): Modifier {
    val top = if (strong) Color(0xF5FFFFFF) else Color(0xCCFFFFFF)
    val bottom = if (strong) Color(0xEBF1F5FB) else Color(0xA3EEF3FA)
    return this
        .clip(shape)
        .background(Brush.verticalGradient(listOf(top, bottom)))
        .background(tint)
        .border(1.dp, Color(0xCCFFFFFF), shape)
}
