package com.example.oslauncher

import android.media.AudioManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.collectLatest
import kotlin.math.PI
import kotlin.math.cos

enum class BannerKind { CHARGING, WIFI, HOTSPOT, BLUETOOTH, SOUND, VOLUME }

data class BannerEvent(
    val id: Long,
    val kind: BannerKind,
    val title: String,
    val subtitle: String,
    val positive: Boolean = true,
    val level: Float? = null,
    val ringerMode: Int = AudioManager.RINGER_MODE_NORMAL
)

/** Floating banner at the top; auto-dismisses after ~2.6 s, a new event restarts the timer. */
@Composable
fun BannerHost(events: Flow<BannerEvent>, modifier: Modifier = Modifier) {
    var current by remember { mutableStateOf<BannerEvent?>(null) }
    var visible by remember { mutableStateOf(false) }

    LaunchedEffect(events) {
        events.collectLatest { e ->
            current = e
            visible = true
            delay(2600)
            visible = false
        }
    }

    AnimatedVisibility(
        visible = visible,
        modifier = modifier,
        enter = slideInVertically(tween(320)) { -it } + fadeIn(tween(220)),
        exit = slideOutVertically(tween(260)) { -it } + fadeOut(tween(200))
    ) {
        current?.let { e ->
            // Volume presses keep the same card (bar just slides); everything else restarts its animation.
            key(if (e.kind == BannerKind.VOLUME) "volume" else e.id.toString()) { BannerCard(e) }
        }
    }
}

@Composable
private fun BannerCard(e: BannerEvent) {
    val accent = when {
        e.kind == BannerKind.VOLUME -> NeonCyan
        e.kind == BannerKind.SOUND -> if (e.ringerMode == AudioManager.RINGER_MODE_SILENT) NeonRed else NeonBlue
        !e.positive -> NeonRed
        e.kind == BannerKind.BLUETOOTH -> NeonBlue
        else -> NeonGreen
    }
    val shape = RoundedCornerShape(30.dp)
    Row(
        Modifier
            .widthIn(max = 420.dp)
            .fillMaxWidth()
            .shadow(10.dp, shape, clip = false)
            .acrylic(shape, strong = true)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BannerIcon(e, accent)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(e.title, color = Win.Ink, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(e.subtitle, color = Win.InkDim, fontSize = 12.sp, maxLines = 1)
            e.level?.let { LevelBar(it, accent, Modifier.padding(top = 6.dp)) }
        }
    }
}

@Composable
private fun BannerIcon(e: BannerEvent, accent: Color) {
    val transition = rememberInfiniteTransition(label = "pulse")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing)),
        label = "phase"
    )
    val pop = remember { Animatable(0.4f) }
    LaunchedEffect(Unit) {
        pop.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium))
    }
    val fill = remember { Animatable(0f) }
    LaunchedEffect(e.id) { fill.animateTo(e.level ?: 0f, tween(700)) }

    Box(Modifier.size(56.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension / 2f
            when (e.kind) {
                BannerKind.CHARGING -> {
                    // soft pulsing green glow
                    val pulse = 0.5f - 0.5f * cos((2.0 * PI * phase).toFloat())
                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(accent.copy(alpha = 0.20f + 0.40f * pulse), Color.Transparent),
                            center = center, radius = r
                        ),
                        radius = r
                    )
                }
                BannerKind.WIFI, BannerKind.HOTSPOT, BannerKind.BLUETOOTH -> {
                    // expanding pulse rings
                    for (i in 0..1) {
                        val p = (phase + i * 0.5f) % 1f
                        drawCircle(
                            color = accent.copy(alpha = (1f - p) * 0.55f),
                            radius = r * (0.45f + 0.55f * p),
                            style = Stroke(width = 3.dp.toPx())
                        )
                    }
                }
                else -> Unit
            }
        }
        val g = Modifier.size(30.dp).scale(pop.value)
        when (e.kind) {
            BannerKind.CHARGING -> BatteryGlyph(accent, fill.value, g)
            BannerKind.WIFI -> WifiGlyph(accent, g)
            BannerKind.HOTSPOT -> HotspotGlyph(accent, g)
            BannerKind.BLUETOOTH -> BluetoothGlyph(accent, g)
            BannerKind.SOUND -> when (e.ringerMode) {
                AudioManager.RINGER_MODE_VIBRATE -> VibrateGlyph(accent, g)
                AudioManager.RINGER_MODE_SILENT -> SpeakerGlyph(accent, true, g)
                else -> SpeakerGlyph(accent, false, g)
            }
            BannerKind.VOLUME -> SpeakerGlyph(accent, false, g)
        }
    }
}

@Composable
private fun LevelBar(level: Float, color: Color, modifier: Modifier = Modifier) {
    val p = remember { Animatable(0f) }
    LaunchedEffect(level) { p.animateTo(level, tween(450)) }
    Box(
        modifier
            .fillMaxWidth()
            .height(5.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(Color(0x1F000000))
    ) {
        Box(
            Modifier
                .fillMaxHeight()
                .fillMaxWidth(p.value.coerceIn(0.02f, 1f))
                .background(color)
        )
    }
}
