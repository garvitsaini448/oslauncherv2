package com.example.oslauncher

import android.content.res.Configuration
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

class HomeActions(
    val onLaunch: (AppEntry) -> Unit,
    val onUninstall: (AppEntry) -> Unit,
    val onInfo: (AppEntry) -> Unit,
    val onRestore: () -> Unit,
    val onRequestPermissions: () -> Unit,
    val onAllFilesAccess: () -> Unit,
    val onOpenMedia: (MediaHit) -> Unit,
    val onWebSearch: (String) -> Unit,
    val onYoutubeSearch: (String) -> Unit
)

/** Everything the two layouts (portrait / landscape) need, so they stay thin. */
private class HomeCtx(
    val statusVm: StatusViewModel,
    val weatherVm: WeatherViewModel,
    val musicVm: MusicViewModel,
    val settings: LauncherSettings,
    val grouped: Map<AppCategory, List<AppEntry>>,
    val pinned: List<AppEntry>,
    val swipeUp: NestedScrollConnection,
    val onSecret: () -> Unit,
    val onLibrary: () -> Unit,
    val onFolder: (AppCategory) -> Unit,
    val onLaunch: (AppEntry) -> Unit,
    val onLongPress: (AppEntry) -> Unit,
    val onRequestPerms: () -> Unit
)

@Composable
fun HomeScreen(
    statusVm: StatusViewModel,
    appsVm: AppsViewModel,
    musicVm: MusicViewModel,
    weatherVm: WeatherViewModel,
    settingsVm: SettingsViewModel,
    searchVm: SearchViewModel,
    homeTick: Int,
    actions: HomeActions
) {
    val apps by appsVm.apps.collectAsStateWithLifecycle()
    val songs by musicVm.songs.collectAsStateWithLifecycle()
    val currentId by musicVm.currentId.collectAsStateWithLifecycle()
    val settings by settingsVm.settings.collectAsStateWithLifecycle()
    val query by searchVm.query.collectAsStateWithLifecycle()
    val media by searchVm.media.collectAsStateWithLifecycle()

    var drawerOpen by remember { mutableStateOf(false) }
    var folder by remember { mutableStateOf<AppCategory?>(null) }
    var settingsOpen by remember { mutableStateOf(false) }
    var songsOpen by remember { mutableStateOf(false) }
    var menuApp by remember { mutableStateOf<AppEntry?>(null) }

    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val searching = query.isNotBlank()
    val focusManager = LocalFocusManager.current

    val grouped = remember(apps) { apps.groupBy { it.category } }
    val pinnedApps = remember(apps, settings.pinned) {
        settings.pinned.mapNotNull { pkg -> apps.firstOrNull { it.packageName == pkg } }
    }

    // Home pressed again -> back to a clean home screen
    LaunchedEffect(homeTick) {
        if (homeTick > 0) {
            drawerOpen = false
            folder = null
            searchVm.setQuery("")
            focusManager.clearFocus()
        }
    }

    BackHandler(enabled = drawerOpen || searching) {
        if (drawerOpen) drawerOpen = false
        else { searchVm.setQuery(""); focusManager.clearFocus() }
    }

    val launch: (AppEntry) -> Unit = {
        searchVm.setQuery("")
        drawerOpen = false
        folder = null
        focusManager.clearFocus()
        actions.onLaunch(it)
    }
    val longPress: (AppEntry) -> Unit = { menuApp = it }

    // Swipe up past the end of the home content -> open the app drawer
    val swipeUp = remember {
        object : NestedScrollConnection {
            var pulled = 0f
            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (source == NestedScrollSource.Drag) {
                    if (available.y < 0f) {
                        pulled += available.y
                        if (pulled < -140f) { pulled = 0f; drawerOpen = true }
                    } else pulled = 0f
                }
                return Offset.Zero
            }
            override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                pulled = 0f
                return Velocity.Zero
            }
        }
    }

    val ctx = HomeCtx(
        statusVm, weatherVm, musicVm, settings, grouped, pinnedApps, swipeUp,
        onSecret = { settingsOpen = true },
        onLibrary = { songsOpen = true },
        onFolder = { folder = it },
        onLaunch = launch,
        onLongPress = longPress,
        onRequestPerms = actions.onRequestPermissions
    )

    val allInsets = WindowInsets.systemBars.union(WindowInsets.displayCutout)

    Box(Modifier.fillMaxSize().background(Win.Wash)) {

        // ------------------------------------------- home: portrait <-> landscape cross-fade
        Crossfade(targetState = landscape, animationSpec = tween(320), label = "rotate") { land ->
            if (land) LandscapeHome(ctx) else PortraitHome(ctx)
        }

        // ----------------------------------------- bottom: handle + universal search + results
        // One stable Column so the text field keeps focus while results appear.
        Column(Modifier.fillMaxSize().windowInsetsPadding(allInsets).imePadding()) {
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .then(if (searching) Modifier.background(Color(0xF2F3F6FB)) else Modifier)
            ) {
                if (searching) {
                    SearchResults(
                        query = query,
                        apps = apps,
                        songs = songs,
                        media = media,
                        onApp = launch,
                        onAppLong = longPress,
                        onSong = { musicVm.play(it); searchVm.setQuery(""); focusManager.clearFocus() },
                        onMedia = { actions.onOpenMedia(it) },
                        onWeb = actions.onWebSearch,
                        onYoutube = actions.onYoutubeSearch,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
            if (!searching) {
                DrawerHandle(onOpen = { drawerOpen = true })
            }
            UniversalSearchBar(
                query = query,
                onQuery = searchVm::setQuery,
                onSubmit = { if (query.isNotBlank()) actions.onWebSearch(query.trim()) },
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .widthIn(max = 560.dp)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            )
        }

        // --------------------------------------------------------------- app drawer
        AnimatedVisibility(
            visible = drawerOpen,
            enter = slideInVertically(tween(300)) { it } + fadeIn(tween(200)),
            exit = slideOutVertically(tween(250)) { it } + fadeOut(tween(200))
        ) {
            AppDrawer(
                apps = apps,
                onClose = { drawerOpen = false },
                onLaunch = launch,
                onLongPress = longPress,
                onSettings = { settingsOpen = true },
                modifier = Modifier.windowInsetsPadding(allInsets).imePadding()
            )
        }

        // ------------------------------------------------ floating system banners (top)
        BannerHost(
            events = statusVm.events,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(top = 6.dp, start = 12.dp, end = 12.dp)
        )
    }

    // ------------------------------------------------------------------ dialogs
    folder?.let { cat ->
        FolderDialog(cat, grouped[cat].orEmpty(), onDismiss = { folder = null }, onLaunch = launch, onLongPress = longPress)
    }

    menuApp?.let { app ->
        AppMenuDialog(
            app = app,
            pinned = app.packageName in settings.pinned,
            onDismiss = { menuApp = null },
            onInfo = { menuApp = null; actions.onInfo(app) },
            onPin = { settingsVm.togglePin(app.packageName); menuApp = null },
            onUninstall = { menuApp = null; actions.onUninstall(app) }
        )
    }

    if (songsOpen) {
        SongLibraryDialog(
            songs = songs,
            currentId = currentId,
            onPick = musicVm::play,
            onDismiss = { songsOpen = false }
        )
    }

    if (settingsOpen) {
        SettingsDialog(
            settings = settings,
            onShowWeather = settingsVm::setShowWeather,
            onLiveTiles = settingsVm::setLiveTiles,
            onPermissions = actions.onRequestPermissions,
            onAllFiles = actions.onAllFilesAccess,
            onClearPins = settingsVm::clearPins,
            onRestore = { settingsOpen = false; actions.onRestore() },
            onDismiss = { settingsOpen = false }
        )
    }
}

// ============================================================================ layouts

@Composable
private fun contentInsets(): WindowInsets =
    WindowInsets.systemBars.union(WindowInsets.displayCutout)
        .only(WindowInsetsSides.Horizontal + WindowInsetsSides.Top)

/** Single column: status, music, folder tiles, pinned tiles. */
@Composable
private fun PortraitHome(h: HomeCtx) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(contentInsets())
            .nestedScroll(h.swipeUp),
        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 150.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { StatusWidgetHost(h.statusVm, h.weatherVm, h.settings.showWeather, h.onSecret) }
        item { MusicWidgetHost(h.musicVm, h.onLibrary, h.onRequestPerms) }
        item { SectionTitle("Folders") }
        item { FolderTiles(h.grouped, h.settings.liveTiles, false, h.onFolder) }
        if (h.pinned.isNotEmpty()) {
            item { SectionTitle("Pinned") }
            item { PinnedTiles(apps = h.pinned, columns = 4, onLaunch = h.onLaunch, onLongPress = h.onLongPress) }
        }
    }
}

/** Desktop / tablet style: widgets on the left, Windows tile board on the right. */
@Composable
private fun LandscapeHome(h: HomeCtx) {
    Row(
        Modifier
            .fillMaxSize()
            .windowInsetsPadding(contentInsets())
            .padding(horizontal = 10.dp)
    ) {
        LazyColumn(
            modifier = Modifier.weight(0.42f).fillMaxHeight().nestedScroll(h.swipeUp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 120.dp, end = 6.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { StatusWidgetHost(h.statusVm, h.weatherVm, h.settings.showWeather, h.onSecret) }
            item { MusicWidgetHost(h.musicVm, h.onLibrary, h.onRequestPerms) }
        }
        LazyColumn(
            modifier = Modifier.weight(0.58f).fillMaxHeight().nestedScroll(h.swipeUp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 120.dp, start = 6.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { SectionTitle("Folders") }
            item { FolderTiles(h.grouped, h.settings.liveTiles, true, h.onFolder) }
            if (h.pinned.isNotEmpty()) {
                item { SectionTitle("Pinned") }
                item { PinnedTiles(apps = h.pinned, columns = 5, onLaunch = h.onLaunch, onLongPress = h.onLongPress) }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text.uppercase(), color = Win.InkDim, fontSize = 12.sp,
        fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, top = 4.dp)
    )
}

@Composable
private fun DrawerHandle(onOpen: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { total = 0f }
                ) { _, dy ->
                    total += dy
                    if (total < -60f) { total = 0f; onOpen() }
                }
            }
            .clickable(onClick = onOpen)
            .padding(top = 6.dp, bottom = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.width(44.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color(0x44000000)))
        Text("Swipe up for all apps", color = Win.InkFaint, fontSize = 10.sp, modifier = Modifier.padding(top = 3.dp))
    }
}
