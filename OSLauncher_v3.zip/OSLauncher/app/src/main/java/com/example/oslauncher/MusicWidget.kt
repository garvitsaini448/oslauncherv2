package com.example.oslauncher

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.util.Locale

/** Collects the player state itself (updates every 500 ms while playing) so the rest of Home stays idle. */
@Composable
fun MusicWidgetHost(
    musicVm: MusicViewModel,
    onOpenLibrary: () -> Unit,
    onRequestPermission: () -> Unit,
    modifier: Modifier = Modifier
) {
    val p by musicVm.state.collectAsStateWithLifecycle()
    MusicWidget(
        p = p,
        onToggle = musicVm::toggle,
        onNext = musicVm::next,
        onPrev = musicVm::previous,
        onSeek = musicVm::seekTo,
        onOpenLibrary = onOpenLibrary,
        onRequestPermission = onRequestPermission,
        modifier = modifier
    )
}

@Composable
fun MusicWidget(
    p: PlayerState,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onSeek: (Int) -> Unit,
    onOpenLibrary: () -> Unit,
    onRequestPermission: () -> Unit,
    modifier: Modifier = Modifier
) {
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }

    Column(
        modifier
            .fillMaxWidth()
            .acrylic(RoundedCornerShape(22.dp))
            .padding(14.dp)
    ) {
        if (!p.hasPermission) {
            Text("♪  Music player", color = Win.Ink, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Spacer(Modifier.height(6.dp))
            Text("Allow music access to play songs stored on this phone.", color = Win.InkDim, fontSize = 12.sp)
            TextButton(onClick = onRequestPermission) { Text("Allow access", color = NeonCyan) }
            return@Column
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(86.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF7AA7FF), Color(0xFF9BE7E0)))),
                contentAlignment = Alignment.Center
            ) {
                val art = p.art
                if (art != null) {
                    Image(art, contentDescription = "Album art", contentScale = ContentScale.Crop, modifier = Modifier.size(86.dp))
                } else {
                    Text("♪", color = Color.White, fontSize = 38.sp)
                }
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    p.current?.title ?: if (p.songs.isEmpty()) "No songs found" else "Tap play",
                    color = Win.Ink, fontSize = 16.sp, fontWeight = FontWeight.Bold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(p.current?.artist ?: "", color = Win.InkDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    Box(Modifier.clip(CircleShape).clickable(onClick = onPrev).padding(6.dp)) { SkipGlyph(Win.Ink, forward = false) }
                    Box(
                        Modifier.size(46.dp).clip(CircleShape).background(NeonCyan).clickable(onClick = onToggle),
                        contentAlignment = Alignment.Center
                    ) {
                        if (p.isPlaying) PauseGlyph(Color.White, Modifier.size(26.dp)) else PlayGlyph(Color.White, Modifier.size(26.dp))
                    }
                    Box(Modifier.clip(CircleShape).clickable(onClick = onNext).padding(6.dp)) { SkipGlyph(Win.Ink, forward = true) }
                }
            }
        }

        val dur = p.durationMs.coerceAtLeast(1)
        val shown = (if (dragging) dragValue else p.positionMs.toFloat()).coerceIn(0f, dur.toFloat())
        Slider(
            value = shown,
            onValueChange = { dragging = true; dragValue = it },
            onValueChangeFinished = { onSeek(dragValue.toInt()); dragging = false },
            valueRange = 0f..dur.toFloat(),
            enabled = p.current != null,
            colors = SliderDefaults.colors(
                thumbColor = NeonCyan, activeTrackColor = NeonCyan, inactiveTrackColor = Color(0x22000000)
            )
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(fmtTime(shown.toInt()), color = Win.InkDim, fontSize = 11.sp)
            TextButton(onClick = onOpenLibrary) { Text("Library (${p.songs.size})", color = NeonCyan, fontSize = 12.sp) }
            Text(fmtTime(dur), color = Win.InkDim, fontSize = 11.sp)
        }
    }
}

private fun fmtTime(ms: Int): String {
    val s = ms / 1000
    return String.format(Locale.US, "%d:%02d", s / 60, s % 60)
}

@Composable
fun SongLibraryDialog(songs: List<Song>, currentId: Long?, onPick: (Song) -> Unit, onDismiss: () -> Unit) {
    val maxH = (LocalConfiguration.current.screenHeightDp * 0.62f).dp
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(22.dp), color = Win.Sheet) {
            Column(Modifier.padding(16.dp)) {
                Text("Music library (${songs.size})", color = Win.Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                if (songs.isEmpty()) {
                    Text("No songs found on this device.", color = Win.InkDim, fontSize = 13.sp)
                } else {
                    LazyColumn(Modifier.heightIn(max = maxH)) {
                        items(songs, key = { it.id }) { s ->
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onPick(s); onDismiss() }
                                    .padding(horizontal = 8.dp, vertical = 9.dp)
                            ) {
                                Text(
                                    s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp,
                                    color = if (s.id == currentId) NeonCyan else Win.Ink,
                                    fontWeight = if (s.id == currentId) FontWeight.Bold else FontWeight.Normal
                                )
                                Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp, color = Win.InkFaint)
                            }
                        }
                    }
                }
                TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) { Text("Close", color = NeonCyan) }
            }
        }
    }
}
