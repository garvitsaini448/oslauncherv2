package com.example.oslauncher

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.util.Locale

/** Collects status/weather itself so the 1-second speed updates only recompose THIS widget. */
@Composable
fun StatusWidgetHost(
    statusVm: StatusViewModel,
    weatherVm: WeatherViewModel,
    showWeather: Boolean,
    onSecretGesture: () -> Unit,
    modifier: Modifier = Modifier
) {
    val s by statusVm.state.collectAsStateWithLifecycle()
    val w by weatherVm.state.collectAsStateWithLifecycle()
    StatusWidget(s, w, showWeather, onSecretGesture, modifier)
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun StatusWidget(
    s: StatusState,
    w: WeatherState,
    showWeather: Boolean,
    onSecretGesture: () -> Unit,
    modifier: Modifier = Modifier
) {
    val netColor = if (s.hotspotOn || s.wifiConnected) NeonGreen else NeonRed

    Column(
        modifier
            .fillMaxWidth()
            .acrylic(RoundedCornerShape(22.dp))
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Long-press the clock = secret gesture -> Launcher Settings
            Column(Modifier.combinedClickable(onClick = {}, onLongClick = onSecretGesture)) {
                Text(s.time, color = Win.Ink, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text(s.date, color = Win.InkDim, fontSize = 12.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                if (s.hotspotOn) HotspotGlyph(NeonGreen) else WifiGlyph(netColor)
                BluetoothGlyph(if (s.bluetoothOn) NeonBlue else IdleGray)
                BatteryIndicator(s.batteryPercent, s.charging)
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Pill("↓ ${fmtSpeed(s.downBytesPerSec)}   ↑ ${fmtSpeed(s.upBytesPerSec)}", NeonCyan)
            if (showWeather) {
                val text = when {
                    !w.online -> "No internet"
                    w.tempC == null -> "Fetching weather…"
                    else -> "${w.emoji} ${w.tempC}°C" + if (w.city.isNotBlank()) "  ·  ${w.city}" else ""
                }
                Pill(text, if (w.online) NeonGreen else NeonRed)
            }
        }
    }
}

@Composable
private fun Pill(text: String, accent: Color) {
    Row(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(accent.copy(alpha = 0.13f))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(accent))
        Spacer(Modifier.width(7.dp))
        Text(text, color = Win.Ink, fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
private fun BatteryIndicator(percent: Int, charging: Boolean) {
    val color = when {
        charging -> NeonGreen
        percent <= 15 -> NeonRed
        else -> Win.Ink
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .width(28.dp).height(13.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(Color(0x22000000))
        ) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth((percent / 100f).coerceIn(0.05f, 1f))
                    .background(color)
            )
        }
        Spacer(Modifier.width(5.dp))
        Text((if (charging) "⚡" else "") + "$percent%", color = Win.Ink, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

private fun fmtSpeed(bytesPerSec: Long): String =
    if (bytesPerSec >= 1_048_576) String.format(Locale.US, "%.1f MB/s", bytesPerSec / 1_048_576.0)
    else String.format(Locale.US, "%d KB/s", bytesPerSec / 1024)
