package com.example.oslauncher

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.abs

val AppCategory.tint: Color
    get() = when (this) {
        AppCategory.FILES -> Color(0xFF0288D1)
        AppCategory.GAMES -> Color(0xFF8E24AA)
        AppCategory.SOCIAL -> Color(0xFF2E9E5B)
        AppCategory.OTHER -> Color(0xFF607D8B)
    }

val AppCategory.emoji: String
    get() = when (this) {
        AppCategory.FILES -> "📁"
        AppCategory.GAMES -> "🎮"
        AppCategory.SOCIAL -> "💬"
        AppCategory.OTHER -> "📱"
    }

private val TilePalette = listOf(
    Color(0xFF0078D7), Color(0xFF00897B), Color(0xFFD32F2F), Color(0xFF6A1B9A),
    Color(0xFFC2185B), Color(0xFF1976D2), Color(0xFFEF6C00), Color(0xFF455A64)
)

/** Icon + label cell used by the drawer and the folder dialog. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppCell(
    app: AppEntry,
    modifier: Modifier = Modifier,
    onLaunch: (AppEntry) -> Unit,
    onLongPress: (AppEntry) -> Unit
) {
    val haptics = LocalHapticFeedback.current
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .combinedClickable(
                onClick = { onLaunch(app) },
                onLongClick = {
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    onLongPress(app)
                }
            )
            .padding(vertical = 6.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(bitmap = app.icon, contentDescription = app.label, modifier = Modifier.size(48.dp))
        Spacer(Modifier.height(4.dp))
        Text(
            app.label, color = Win.Ink, fontSize = 11.sp, maxLines = 2,
            overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, lineHeight = 13.sp
        )
    }
}

/**
 * Portrait: Games + Files medium tiles, Social wide tile.
 * Landscape: all three folders as equal tiles in one row (desktop-style).
 */
@Composable
fun FolderTiles(
    grouped: Map<AppCategory, List<AppEntry>>,
    liveTiles: Boolean,
    landscape: Boolean,
    onOpen: (AppCategory) -> Unit
) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val gap = 8.dp
        if (landscape) {
            val side = (maxWidth - gap * 2) / 3
            Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                listOf(AppCategory.GAMES, AppCategory.FILES, AppCategory.SOCIAL).forEach { c ->
                    FolderTile(c, grouped[c].orEmpty(), liveTiles, false, Modifier.size(side), onOpen)
                }
            }
        } else {
            val unit = (maxWidth - gap * 3) / 4
            val medium = unit * 2 + gap
            Column(verticalArrangement = Arrangement.spacedBy(gap)) {
                Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                    FolderTile(AppCategory.GAMES, grouped[AppCategory.GAMES].orEmpty(), liveTiles, false, Modifier.size(medium), onOpen)
                    FolderTile(AppCategory.FILES, grouped[AppCategory.FILES].orEmpty(), liveTiles, false, Modifier.size(medium), onOpen)
                }
                FolderTile(AppCategory.SOCIAL, grouped[AppCategory.SOCIAL].orEmpty(), liveTiles, true, Modifier.fillMaxWidth().height(medium), onOpen)
            }
        }
    }
}

@Composable
private fun FolderTile(
    cat: AppCategory,
    apps: List<AppEntry>,
    liveTiles: Boolean,
    wide: Boolean,
    modifier: Modifier,
    onOpen: (AppCategory) -> Unit
) {
    val cols = if (wide) 4 else 2
    val rows = 2
    val per = cols * rows
    val pages = remember(apps, per) { apps.chunked(per).ifEmpty { listOf(emptyList<AppEntry>()) } }
    var page by remember(pages.size) { mutableIntStateOf(0) }

    // "Live tile": icons flip to the next page every few seconds
    LaunchedEffect(pages.size, liveTiles) {
        if (liveTiles && pages.size > 1) {
            while (true) {
                delay(4500)
                page = (page + 1) % pages.size
            }
        }
    }

    Box(
        modifier
            .acrylic(RoundedCornerShape(16.dp), tint = cat.tint.copy(alpha = 0.20f))
            .clickable { onOpen(cat) }
    ) {
        Column(Modifier.fillMaxSize().padding(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "${cat.emoji} ${cat.title}", color = Win.Ink, fontSize = 14.sp,
                    fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1
                )
                Text("${apps.size}", color = Win.InkDim, fontSize = 12.sp)
            }
            Spacer(Modifier.height(6.dp))
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (apps.isEmpty()) {
                    Text("Empty", color = Win.InkFaint, fontSize = 12.sp, modifier = Modifier.align(Alignment.Center))
                } else {
                    Crossfade(targetState = page, label = "liveTile") { p ->
                        IconGrid(pages[p.coerceIn(0, pages.lastIndex)], cols, rows)
                    }
                }
            }
        }
    }
}

@Composable
private fun IconGrid(items: List<AppEntry>, cols: Int, rows: Int) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        repeat(rows) { r ->
            Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                repeat(cols) { c ->
                    val app = items.getOrNull(r * cols + c)
                    Box(Modifier.weight(1f).fillMaxSize(), contentAlignment = Alignment.Center) {
                        if (app != null) {
                            Image(app.icon, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize().padding(2.dp))
                        }
                    }
                }
            }
        }
    }
}

/** Pinned apps as small acrylic tiles with a colour wash, 4 per row. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PinnedTiles(
    apps: List<AppEntry>,
    columns: Int = 4,
    onLaunch: (AppEntry) -> Unit,
    onLongPress: (AppEntry) -> Unit
) {
    val haptics = LocalHapticFeedback.current
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val gap = 8.dp
        val unit = (maxWidth - gap * (columns - 1)) / columns
        Column(verticalArrangement = Arrangement.spacedBy(gap)) {
            apps.chunked(columns).forEach { rowApps ->
                Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                    rowApps.forEach { app ->
                        val color = TilePalette[abs(app.packageName.hashCode()) % TilePalette.size]
                        Column(
                            Modifier
                                .size(unit)
                                .acrylic(RoundedCornerShape(14.dp), tint = color.copy(alpha = 0.16f))
                                .combinedClickable(
                                    onClick = { onLaunch(app) },
                                    onLongClick = {
                                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                        onLongPress(app)
                                    }
                                )
                                .padding(6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Image(app.icon, contentDescription = app.label, modifier = Modifier.size(36.dp))
                            Spacer(Modifier.height(3.dp))
                            Text(app.label, color = Win.Ink, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
    }
}
