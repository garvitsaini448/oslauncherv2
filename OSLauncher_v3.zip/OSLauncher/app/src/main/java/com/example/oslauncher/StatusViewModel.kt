package com.example.oslauncher

import android.app.Application
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.TrafficStats
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.SystemClock
import android.text.format.DateFormat
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong

data class StatusState(
    val time: String = "--:--",
    val date: String = "",
    val downBytesPerSec: Long = 0,
    val upBytesPerSec: Long = 0,
    val wifiConnected: Boolean = false,
    val hotspotOn: Boolean = false,
    val bluetoothOn: Boolean = false,
    val batteryPercent: Int = 0,
    val charging: Boolean = false
)

class StatusViewModel(application: Application) : AndroidViewModel(application) {

    private val ctx: Context = application.applicationContext
    private val _state = MutableStateFlow(StatusState())
    val state: StateFlow<StatusState> = _state.asStateFlow()

    // One-shot events for the floating banner (charging, Wi-Fi, hotspot, Bluetooth, sound mode, volume)
    private val _events = MutableSharedFlow<BannerEvent>(
        extraBufferCapacity = 8, onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val events: SharedFlow<BannerEvent> = _events.asSharedFlow()
    private val nextId = AtomicLong(0)

    private fun emit(
        kind: BannerKind, title: String, subtitle: String,
        positive: Boolean = true, level: Float? = null,
        ringer: Int = AudioManager.RINGER_MODE_NORMAL
    ) {
        _events.tryEmit(BannerEvent(nextId.incrementAndGet(), kind, title, subtitle, positive, level, ringer))
    }

    // Speed loop only runs while the launcher is on screen (saves battery/CPU)
    private val visible = MutableStateFlow(true)
    fun setVisible(v: Boolean) { visible.value = v }

    private val connectivity = ctx.getSystemService(ConnectivityManager::class.java)
    private val audio: AudioManager = ctx.getSystemService(AudioManager::class.java)
    private var lastRinger = audio.ringerMode
    private var lastPlugged: Boolean? = null

    // ---------------------------------------------------------------- receivers

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) = applyBattery(intent)
    }

    private val bluetoothReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                BluetoothAdapter.ACTION_STATE_CHANGED -> {
                    val s = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR)
                    if (s == BluetoothAdapter.STATE_ON || s == BluetoothAdapter.STATE_OFF) {
                        val on = s == BluetoothAdapter.STATE_ON
                        if (_state.value.bluetoothOn != on) {
                            _state.update { it.copy(bluetoothOn = on) }
                            emit(
                                BannerKind.BLUETOOTH,
                                if (on) "Bluetooth on" else "Bluetooth off",
                                if (on) "Ready to pair" else "Radio turned off",
                                on
                            )
                        }
                    }
                }
                BluetoothDevice.ACTION_ACL_CONNECTED ->
                    emit(BannerKind.BLUETOOTH, "Bluetooth connected", deviceName(intent) ?: "Device connected", true)
                BluetoothDevice.ACTION_ACL_DISCONNECTED ->
                    emit(BannerKind.BLUETOOTH, "Bluetooth disconnected", deviceName(intent) ?: "Device disconnected", false)
            }
        }
    }

    private val hotspotReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val on = intent.getIntExtra("wifi_state", 11) == 13   // 13 = AP enabled
            if (_state.value.hotspotOn != on) {
                _state.update { it.copy(hotspotOn = on) }
                emit(
                    BannerKind.HOTSPOT,
                    if (on) "Hotspot on" else "Hotspot off",
                    if (on) "Sharing your connection" else "Sharing stopped",
                    on
                )
            }
        }
    }

    private val soundReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                AudioManager.RINGER_MODE_CHANGED_ACTION -> {
                    val m = audio.ringerMode
                    if (m != lastRinger) {
                        lastRinger = m
                        val (title, sub) = when (m) {
                            AudioManager.RINGER_MODE_SILENT -> "Mute" to "Sounds and vibration off"
                            AudioManager.RINGER_MODE_VIBRATE -> "Vibrate" to "Vibration only"
                            else -> "Sound on" to "Ring mode"
                        }
                        emit(BannerKind.SOUND, title, sub, true, null, m)
                    }
                }
                "android.media.VOLUME_CHANGED_ACTION" -> {
                    val stream = intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1)
                    if (stream == AudioManager.STREAM_MUSIC) {
                        val v = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
                        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        emit(
                            BannerKind.VOLUME, "Media volume", "$v / $max",
                            true, if (max > 0) v / max.toFloat() else 0f
                        )
                    }
                }
            }
        }
    }

    private val wifiCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            if (!_state.value.wifiConnected) {
                _state.update { it.copy(wifiConnected = true) }
                emit(BannerKind.WIFI, "Wi-Fi connected", "You're online", true)
            }
        }
        override fun onLost(network: Network) {
            if (_state.value.wifiConnected) {
                _state.update { it.copy(wifiConnected = false) }
                emit(BannerKind.WIFI, "Wi-Fi disconnected", "No Wi-Fi connection", false)
            }
        }
    }

    init {
        // Initial values FIRST (so the registration callbacks below don't fire fake events)
        val btOn = try {
            ctx.getSystemService(BluetoothManager::class.java)?.adapter?.isEnabled == true
        } catch (e: SecurityException) { false }
        val wifiNow = connectivity?.let { cm ->
            cm.getNetworkCapabilities(cm.activeNetwork)
                ?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        } ?: false
        _state.update { it.copy(bluetoothOn = btOn, wifiConnected = wifiNow, hotspotOn = readHotspot()) }

        ContextCompat.registerReceiver(
            ctx, batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )?.let { applyBattery(it) }

        ContextCompat.registerReceiver(
            ctx, bluetoothReceiver,
            IntentFilter().apply {
                addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
                addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
                addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
            },
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        ContextCompat.registerReceiver(
            ctx, hotspotReceiver, IntentFilter("android.net.wifi.WIFI_AP_STATE_CHANGED"),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        ContextCompat.registerReceiver(
            ctx, soundReceiver,
            IntentFilter().apply {
                addAction(AudioManager.RINGER_MODE_CHANGED_ACTION)
                addAction("android.media.VOLUME_CHANGED_ACTION")
            },
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        connectivity?.registerNetworkCallback(
            NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build(),
            wifiCallback
        )

        startTickLoop()
    }

    private fun deviceName(i: Intent): String? = try {
        IntentCompat.getParcelableExtra(i, BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)?.name
    } catch (e: SecurityException) { null }

    private fun readHotspot(): Boolean = try {
        val wm = ctx.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val m = wm.javaClass.getDeclaredMethod("isWifiApEnabled")
        m.isAccessible = true
        (m.invoke(wm) as? Boolean) ?: false
    } catch (e: Throwable) { false }

    private fun applyBattery(i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else 0
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        _state.update { it.copy(batteryPercent = pct, charging = charging) }

        val prev = lastPlugged
        lastPlugged = plugged
        if (prev != null && prev != plugged) {
            if (plugged) emit(BannerKind.CHARGING, "Charging", "$pct%  •  Charger connected", true, pct / 100f)
            else emit(BannerKind.CHARGING, "Charger disconnected", "$pct% remaining", false, pct / 100f)
        }
    }

    private fun startTickLoop() = viewModelScope.launch {
        var lastRx = TrafficStats.getTotalRxBytes()
        var lastTx = TrafficStats.getTotalTxBytes()
        var lastT = SystemClock.elapsedRealtime()

        while (isActive) {
            if (!visible.value) {
                visible.first { it }                       // sleep while the launcher is in the background
                lastRx = TrafficStats.getTotalRxBytes()
                lastTx = TrafficStats.getTotalTxBytes()
                lastT = SystemClock.elapsedRealtime()
            }
            val now = LocalDateTime.now()
            val timePattern = if (DateFormat.is24HourFormat(ctx)) "HH:mm" else "h:mm a"
            val timeStr = now.format(DateTimeFormatter.ofPattern(timePattern, Locale.getDefault()))
            val dateStr = now.format(DateTimeFormatter.ofPattern("EEEE, d MMM", Locale.getDefault()))

            val rx = TrafficStats.getTotalRxBytes()
            val tx = TrafficStats.getTotalTxBytes()
            val t = SystemClock.elapsedRealtime()
            val dt = (t - lastT).coerceAtLeast(1)
            val supported = rx != TrafficStats.UNSUPPORTED.toLong() && tx != TrafficStats.UNSUPPORTED.toLong()
            val down = if (supported) ((rx - lastRx) * 1000 / dt).coerceAtLeast(0) else 0
            val up = if (supported) ((tx - lastTx) * 1000 / dt).coerceAtLeast(0) else 0
            lastRx = rx; lastTx = tx; lastT = t

            _state.update {
                it.copy(time = timeStr, date = dateStr, downBytesPerSec = down, upBytesPerSec = up)
            }
            delay(1000)
        }
    }

    override fun onCleared() {
        runCatching { ctx.unregisterReceiver(batteryReceiver) }
        runCatching { ctx.unregisterReceiver(bluetoothReceiver) }
        runCatching { ctx.unregisterReceiver(hotspotReceiver) }
        runCatching { ctx.unregisterReceiver(soundReceiver) }
        runCatching { connectivity?.unregisterNetworkCallback(wifiCallback) }
        super.onCleared()
    }
}
