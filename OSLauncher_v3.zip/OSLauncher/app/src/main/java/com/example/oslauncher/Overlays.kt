package com.example.oslauncher

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

@Composable
private fun dialogMaxHeight(fraction: Float): Dp =
    (LocalConfiguration.current.screenHeightDp * fraction).dp

// ======================================================================== search bar

@Composable
fun UniversalSearchBar(
    query: String,
    onQuery: (String) -> Unit,
    onSubmit: () -> Unit,
    modifier: Modifier = Modifier
) {
    BasicTextField(
        value = query,
        onValueChange = onQuery,
        singleLine = true,
        textStyle = TextStyle(color = Win.Ink, fontSize = 16.sp),
        cursorBrush = SolidColor(NeonCyan),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onSubmit() }),
        modifier = modifier.fillMaxWidth(),
        decorationBox = { inner ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .acrylic(RoundedCornerShape(30.dp), strong = true)
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SearchGlyph(NeonCyan, Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
                Box(Modifier.weight(1f)) {
                    if (query.isEmpty()) {
                        Text("Search apps, songs, videos, files…", color = Win.InkFaint, fontSize = 15.sp, maxLines = 1)
                    }
                    inner()
                }
                if (query.isNotEmpty()) {
                    Box(Modifier.clip(RoundedCornerShape(50)).clickable { onQuery("") }.padding(4.dp)) {
                        CloseGlyph(Win.InkDim, Modifier.size(16.dp))
                    }
                }
            }
        }
    )
}

// ===================================================================== search results

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SearchResults(
    query: String,
    apps: List<AppEntry>,
    songs: List<Song>,
    media: MediaResults,
    onApp: (AppEntry) -> Unit,
    onAppLong: (AppEntry) -> Unit,
    onSong: (Song) -> Unit,
    onMedia: (MediaHit) -> Unit,
    onWeb: (String) -> Unit,
    onYoutube: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val q = query.trim()
    val appHits = remember(apps, q) { apps.filter { it.label.contains(q, ignoreCase = true) }.take(8) }
    val songHits = remember(songs, q) {
        songs.filter { it.title.contains(q, ignoreCase = true) || it.artist.contains(q, ignoreCase = true) }.take(8)
    }
    val none = appHits.isEmpty() && songHits.isEmpty() && media.videos.isEmpty() && media.files.isEmpty()

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        if (none) {
            item {
                Text(
                    "Nothing on this phone matches \"$q\"",
                    color = Win.InkDim, fontSize = 14.sp, modifier = Modifier.padding(vertical = 10.dp)
                )
            }
        }
        if (appHits.isNotEmpty()) {
            item(key = "h_apps") { ResultHeader("Apps") }
            items(appHits, key = { "app_" + it.packageName }) { a ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                        .combinedClickable(onClick = { onApp(a) }, onLongClick = { onAppLong(a) })
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(a.icon, contentDescription = null, modifier = Modifier.size(38.dp))
                    Spacer(Modifier.width(12.dp))
                    Text(a.label, color = Win.Ink, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        if (songHits.isNotEmpty()) {
            item(key = "h_songs") { ResultHeader("Songs") }
            items(songHits, key = { "song_" + it.id }) { s -> ResultRow("🎵", s.title, s.artist) { onSong(s) } }
        }
        if (media.videos.isNotEmpty()) {
            item(key = "h_videos") { ResultHeader("Videos") }
            items(media.videos, key = { "vid_" + it.uri }) { v -> ResultRow(v.emoji, v.title, v.subtitle) { onMedia(v) } }
        }
        if (media.files.isNotEmpty()) {
            item(key = "h_files") { ResultHeader("Files") }
            items(media.files, key = { "file_" + it.uri }) { f -> ResultRow(f.emoji, f.title, f.subtitle) { onMedia(f) } }
        }
        item(key = "h_web") { ResultHeader(if (none) "Search online" else "Not what you need? Search online") }
        item(key = "web_google") { ResultRow("🌐", "Search \"$q\" on the web", "Opens your browser") { onWeb(q) } }
        item(key = "web_youtube") { ResultRow("▶️", "Search \"$q\" on YouTube", "Opens YouTube") { onYoutube(q) } }
    }
}

@Composable
private fun ResultHeader(text: String) {
    Text(
        text, color = NeonCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 10.dp, bottom = 4.dp, start = 4.dp)
    )
}

@Composable
private fun ResultRow(emoji: String, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(38.dp).clip(RoundedCornerShape(10.dp)).background(Color(0x14000000)),
            contentAlignment = Alignment.Center
        ) { Text(emoji, fontSize = 18.sp) }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, color = Win.Ink, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (subtitle.isNotBlank()) {
                Text(subtitle, color = Win.InkFaint, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

// ======================================================================== app drawer

@Composable
fun AppDrawer(
    apps: List<AppEntry>,
    onClose: () -> Unit,
    onLaunch: (AppEntry) -> Unit,
    onLongPress: (AppEntry) -> Unit,
    onSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    var q by remember { mutableStateOf("") }
    val filtered = remember(apps, q) {
        if (q.isBlank()) apps else apps.filter { it.label.contains(q.trim(), ignoreCase = true) }
    }

    Surface(color = Win.Sheet, modifier = Modifier.fillMaxSize()) {
        Column(modifier.fillMaxSize()) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(30.dp)
                    .pointerInput(Unit) {
                        var total = 0f
                        detectVerticalDragGestures(
                            onDragStart = { total = 0f },
                            onDragEnd = { total = 0f }
                        ) { _, dy ->
                            total += dy
                            if (total > 90f) { total = 0f; onClose() }
                        }
                    }
                    .clickable(onClick = onClose),
                contentAlignment = Alignment.Center
            ) {
                Box(Modifier.width(44.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color(0x33000000)))
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                BasicTextField(
                    value = q,
                    onValueChange = { q = it },
                    singleLine = true,
                    textStyle = TextStyle(color = Win.Ink, fontSize = 16.sp),
                    cursorBrush = SolidColor(NeonCyan),
                    modifier = Modifier.weight(1f),
                    decorationBox = { inner ->
                        Row(
                            Modifier.fillMaxWidth()
                                .acrylic(RoundedCornerShape(26.dp))
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            SearchGlyph(Win.InkDim, Modifier.size(18.dp))
                            Spacer(Modifier.width(10.dp))
                            Box {
                                if (q.isEmpty()) Text("Search all apps", color = Win.InkFaint, fontSize = 15.sp)
                                inner()
                            }
                        }
                    }
                )
                Spacer(Modifier.width(8.dp))
                Box(Modifier.clip(RoundedCornerShape(50)).clickable(onClick = onSettings).padding(10.dp)) {
                    SettingsGlyph(Win.Ink)
                }
            }
            Text(
                "${filtered.size} apps", color = Win.InkFaint, fontSize = 11.sp,
                modifier = Modifier.padding(start = 18.dp, top = 8.dp)
            )
            // Adaptive: 4 columns in portrait, ~9 in landscape
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 76.dp),
                contentPadding = PaddingValues(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(filtered, key = { it.packageName }) { app ->
                    AppCell(app, Modifier, onLaunch, onLongPress)
                }
            }
        }
    }
}

// ========================================================================== dialogs

@Composable
fun AppMenuDialog(
    app: AppEntry,
    pinned: Boolean,
    onDismiss: () -> Unit,
    onInfo: () -> Unit,
    onPin: () -> Unit,
    onUninstall: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(24.dp), color = Win.Sheet) {
            Column(
                Modifier.padding(20.dp).verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(app.icon, contentDescription = null, modifier = Modifier.size(56.dp))
                Spacer(Modifier.height(8.dp))
                Text(app.label, color = Win.Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(app.packageName, color = Win.InkFaint, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(14.dp))
                MenuRow("ℹ️  App Info", Win.Ink, true, onInfo)
                Spacer(Modifier.height(8.dp))
                MenuRow(if (pinned) "📌  Unpin from Tile" else "📌  Pin to Tile", NeonCyan, true, onPin)
                Spacer(Modifier.height(8.dp))
                MenuRow(
                    if (app.canUninstall) "🗑️  Uninstall / Delete App" else "🗑️  System app (can't uninstall)",
                    if (app.canUninstall) NeonRed else IdleGray,
                    app.canUninstall, onUninstall
                )
                TextButton(onClick = onDismiss) { Text("Cancel", color = NeonCyan) }
            }
        }
    }
}

@Composable
private fun MenuRow(text: String, color: Color, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0x0F000000))
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp)
    ) { Text(text, color = color, fontSize = 15.sp, fontWeight = FontWeight.Medium) }
}

@Composable
fun FolderDialog(
    category: AppCategory,
    apps: List<AppEntry>,
    onDismiss: () -> Unit,
    onLaunch: (AppEntry) -> Unit,
    onLongPress: (AppEntry) -> Unit
) {
    val maxH = dialogMaxHeight(0.62f)
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(shape = RoundedCornerShape(18.dp), color = Win.Sheet, modifier = Modifier.fillMaxWidth(0.92f)) {
            Column(Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "${category.emoji}  ${category.title}", color = Win.Ink, fontSize = 18.sp,
                        fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)
                    )
                    Text("${apps.size}", color = Win.InkFaint, fontSize = 13.sp)
                }
                Spacer(Modifier.height(8.dp))
                if (apps.isEmpty()) {
                    Text("No apps detected in this folder yet.", color = Win.InkDim, fontSize = 13.sp)
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(minSize = 76.dp),
                        modifier = Modifier.heightIn(max = maxH)
                    ) {
                        items(apps, key = { it.packageName }) { app -> AppCell(app, Modifier, onLaunch, onLongPress) }
                    }
                }
                TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) { Text("Close", color = NeonCyan) }
            }
        }
    }
}

@Composable
fun SettingsDialog(
    settings: LauncherSettings,
    onShowWeather: (Boolean) -> Unit,
    onLiveTiles: (Boolean) -> Unit,
    onPermissions: () -> Unit,
    onAllFiles: () -> Unit,
    onClearPins: () -> Unit,
    onRestore: () -> Unit,
    onDismiss: () -> Unit
) {
    val maxH = dialogMaxHeight(0.85f)
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(shape = RoundedCornerShape(24.dp), color = Win.Sheet, modifier = Modifier.fillMaxWidth(0.92f)) {
            Column(Modifier.padding(18.dp).heightIn(max = maxH).verticalScroll(rememberScrollState())) {
                Text("Launcher Settings", color = Win.Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                SwitchRow("Show live weather", settings.showWeather, onShowWeather)
                SwitchRow("Animate live tiles", settings.liveTiles, onLiveTiles)
                Spacer(Modifier.height(10.dp))
                MenuRow("🔑  Grant location, media & Bluetooth access", Win.Ink, true, onPermissions)
                Spacer(Modifier.height(8.dp))
                MenuRow("📂  All-files access (search documents)", Win.Ink, true, onAllFiles)
                Spacer(Modifier.height(8.dp))
                MenuRow("📌  Clear pinned tiles (${settings.pinned.size})", Win.Ink, settings.pinned.isNotEmpty(), onClearPins)
                Spacer(Modifier.height(16.dp))
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(NeonRed)
                        .clickable(onClick = onRestore).padding(horizontal = 16.dp, vertical = 15.dp)
                ) {
                    Text("↩  Restore One UI / Switch default launcher", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    "Tip: long-press the clock on the home screen to open this menu. Rotation follows your phone's Auto-rotate setting.",
                    color = Win.InkFaint, fontSize = 11.sp
                )
                TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) { Text("Close", color = NeonCyan) }
            }
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Win.Ink, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
