package com.example.oslauncher

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

val NeonGreen = Color(0xFF00B85C)
val NeonRed = Color(0xFFE5173F)
val NeonBlue = Color(0xFF0078D4)
val NeonCyan = Color(0xFF0067C0)
val IdleGray = Color(0xFF8A94A3)

private fun DrawScope.glowArc(color: Color, center: Offset, r: Float, start: Float, sweep: Float, sw: Float) {
    val tl = Offset(center.x - r, center.y - r)
    val sz = Size(r * 2f, r * 2f)
    drawArc(color.copy(alpha = 0.25f), start, sweep, false, tl, sz, style = Stroke(sw * 2.4f, cap = StrokeCap.Round))
    drawArc(color, start, sweep, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
}

private fun DrawScope.glowDot(color: Color, center: Offset, r: Float) {
    drawCircle(color.copy(alpha = 0.25f), r * 1.9f, center)
    drawCircle(color, r, center)
}

@Composable
fun WifiGlyph(color: Color, modifier: Modifier = Modifier.size(26.dp)) {
    Canvas(modifier) {
        val w = size.width
        val c = Offset(w / 2f, size.height * 0.86f)
        val sw = w * 0.09f
        listOf(0.68f, 0.46f, 0.24f).forEach { f -> glowArc(color, c, w * f, 225f, 90f, sw) }
        glowDot(color, c, sw * 1.1f)
    }
}

@Composable
fun HotspotGlyph(color: Color, modifier: Modifier = Modifier.size(26.dp)) {
    Canvas(modifier) {
        val w = size.width
        val c = Offset(w / 2f, size.height / 2f)
        val sw = w * 0.09f
        listOf(0.22f, 0.38f).forEach { f ->
            glowArc(color, c, w * f, -40f, 80f, sw)
            glowArc(color, c, w * f, 140f, 80f, sw)
        }
        glowDot(color, c, w * 0.09f)
    }
}

@Composable
fun BluetoothGlyph(color: Color, modifier: Modifier = Modifier.size(22.dp)) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val p = Path().apply {
            moveTo(w * 0.25f, h * 0.30f)
            lineTo(w * 0.75f, h * 0.70f)
            lineTo(w * 0.50f, h * 0.92f)
            lineTo(w * 0.50f, h * 0.08f)
            lineTo(w * 0.75f, h * 0.30f)
            lineTo(w * 0.25f, h * 0.70f)
        }
        drawPath(p, color.copy(alpha = 0.25f), style = Stroke(w * 0.22f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawPath(p, color, style = Stroke(w * 0.09f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
fun PlayGlyph(color: Color, modifier: Modifier = Modifier.size(28.dp)) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val p = Path().apply {
            moveTo(w * 0.28f, h * 0.18f)
            lineTo(w * 0.82f, h * 0.50f)
            lineTo(w * 0.28f, h * 0.82f)
            close()
        }
        drawPath(p, color)
    }
}

@Composable
fun PauseGlyph(color: Color, modifier: Modifier = Modifier.size(28.dp)) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        drawRect(color, Offset(w * 0.22f, h * 0.18f), Size(w * 0.20f, h * 0.64f))
        drawRect(color, Offset(w * 0.58f, h * 0.18f), Size(w * 0.20f, h * 0.64f))
    }
}

@Composable
fun SkipGlyph(color: Color, forward: Boolean, modifier: Modifier = Modifier.size(24.dp)) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        fun fx(x: Float) = if (forward) x * w else (1f - x) * w
        val tri = Path().apply {
            moveTo(fx(0.18f), h * 0.20f)
            lineTo(fx(0.68f), h * 0.50f)
            lineTo(fx(0.18f), h * 0.80f)
            close()
        }
        drawPath(tri, color)
        val left = minOf(fx(0.74f), fx(0.84f))
        drawRect(color, Offset(left, h * 0.20f), Size(w * 0.10f, h * 0.60f))
    }
}

@Composable
fun SearchGlyph(color: Color, modifier: Modifier = Modifier.size(20.dp)) {
    Canvas(modifier) {
        val w = size.width
        val sw = w * 0.11f
        drawCircle(color, w * 0.30f, Offset(w * 0.42f, w * 0.42f), style = Stroke(sw))
        drawLine(color, Offset(w * 0.64f, w * 0.64f), Offset(w * 0.92f, w * 0.92f), sw, StrokeCap.Round)
    }
}

@Composable
fun CloseGlyph(color: Color, modifier: Modifier = Modifier.size(18.dp)) {
    Canvas(modifier) {
        val w = size.width
        val sw = w * 0.12f
        drawLine(color, Offset(w * 0.2f, w * 0.2f), Offset(w * 0.8f, w * 0.8f), sw, StrokeCap.Round)
        drawLine(color, Offset(w * 0.8f, w * 0.2f), Offset(w * 0.2f, w * 0.8f), sw, StrokeCap.Round)
    }
}

@Composable
fun SettingsGlyph(color: Color, modifier: Modifier = Modifier.size(22.dp)) {
    Canvas(modifier) {
        val w = size.width
        val sw = w * 0.08f
        listOf(0.25f to 0.68f, 0.50f to 0.32f, 0.75f to 0.62f).forEach { (y, kx) ->
            drawLine(color, Offset(w * 0.1f, w * y), Offset(w * 0.9f, w * y), sw, StrokeCap.Round)
            drawCircle(color, w * 0.10f, Offset(w * kx, w * y))
        }
    }
}

@Composable
fun BatteryGlyph(color: Color, fill: Float, modifier: Modifier = Modifier.size(30.dp)) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val sw = w * 0.07f
        val bodyL = w * 0.26f
        val bodyT = h * 0.16f
        val bodyW = w * 0.48f
        val bodyH = h * 0.76f
        drawRoundRect(color, Offset(w * 0.40f, h * 0.05f), Size(w * 0.20f, h * 0.10f), CornerRadius(sw))
        val inset = sw * 1.2f
        val f = fill.coerceIn(0f, 1f)
        val fh = (bodyH - inset * 2f) * f
        drawRoundRect(
            color.copy(alpha = 0.9f),
            Offset(bodyL + inset, bodyT + bodyH - inset - fh),
            Size(bodyW - inset * 2f, fh),
            CornerRadius(sw * 0.5f)
        )
        drawRoundRect(color, Offset(bodyL, bodyT), Size(bodyW, bodyH), CornerRadius(sw * 1.5f), style = Stroke(sw))
        val bolt = Path().apply {
            moveTo(w * 0.54f, h * 0.30f)
            lineTo(w * 0.41f, h * 0.56f)
            lineTo(w * 0.50f, h * 0.56f)
            lineTo(w * 0.46f, h * 0.78f)
            lineTo(w * 0.60f, h * 0.50f)
            lineTo(w * 0.51f, h * 0.50f)
            close()
        }
        drawPath(bolt, if (f > 0.55f) Color.White else color)
    }
}

@Composable
fun SpeakerGlyph(color: Color, muted: Boolean, modifier: Modifier = Modifier.size(30.dp)) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val sw = w * 0.08f
        val body = Path().apply {
            moveTo(w * 0.12f, h * 0.38f)
            lineTo(w * 0.30f, h * 0.38f)
            lineTo(w * 0.50f, h * 0.20f)
            lineTo(w * 0.50f, h * 0.80f)
            lineTo(w * 0.30f, h * 0.62f)
            lineTo(w * 0.12f, h * 0.62f)
            close()
        }
        drawPath(body, color)
        if (muted) {
            drawLine(color, Offset(w * 0.62f, h * 0.38f), Offset(w * 0.88f, h * 0.62f), sw, StrokeCap.Round)
            drawLine(color, Offset(w * 0.88f, h * 0.38f), Offset(w * 0.62f, h * 0.62f), sw, StrokeCap.Round)
        } else {
            val c = Offset(w * 0.50f, h * 0.50f)
            listOf(0.20f, 0.34f).forEach { f ->
                drawArc(
                    color, -45f, 90f, false,
                    Offset(c.x - w * f, c.y - w * f), Size(w * f * 2f, w * f * 2f),
                    style = Stroke(sw, cap = StrokeCap.Round)
                )
            }
        }
    }
}

@Composable
fun VibrateGlyph(color: Color, modifier: Modifier = Modifier.size(30.dp)) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val sw = w * 0.07f
        drawRoundRect(
            color, Offset(w * 0.34f, h * 0.16f), Size(w * 0.32f, h * 0.68f),
            CornerRadius(w * 0.06f), style = Stroke(sw)
        )
        val c = Offset(w / 2f, h / 2f)
        listOf(0.30f, 0.44f).forEach { f ->
            val tl = Offset(c.x - w * f, c.y - w * f)
            val sz = Size(w * f * 2f, w * f * 2f)
            drawArc(color, 140f, 80f, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
            drawArc(color, -40f, 80f, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
        }
    }
}
