package com.example.oslauncher

import android.app.Application
import android.content.Context
import android.location.Geocoder
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.roundToInt

data class WeatherState(
    val online: Boolean = false,
    val tempC: Int? = null,
    val emoji: String = "",
    val description: String = "",
    val city: String = ""
)

/**
 * Weather via Open-Meteo (free, no API key).
 * Location: last known coarse location if permission granted, otherwise IP-based city lookup.
 */
class WeatherViewModel(application: Application) : AndroidViewModel(application) {

    private val ctx: Context = application.applicationContext
    private val _state = MutableStateFlow(WeatherState())
    val state: StateFlow<WeatherState> = _state.asStateFlow()

    private val cm: ConnectivityManager = ctx.getSystemService(ConnectivityManager::class.java)
    private var lastFetch = 0L
    @Volatile private var fetching = false

    private val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            _state.update { it.copy(online = true) }
            refresh(false)
        }
        override fun onLost(network: Network) {
            _state.update { it.copy(online = false) }
        }
    }

    init {
        val online = cm.getNetworkCapabilities(cm.activeNetwork)
            ?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        _state.update { it.copy(online = online) }
        cm.registerDefaultNetworkCallback(callback)
        viewModelScope.launch {
            while (isActive) {
                delay(60_000L)
                refresh(false)   // re-checks only when data is older than 15 min or never loaded
            }
        }
        refresh(false)
    }

    fun refresh(force: Boolean) {
        if (!_state.value.online || fetching) return
        val now = SystemClock.elapsedRealtime()
        if (!force && lastFetch != 0L && now - lastFetch < 15 * 60_000L) return
        fetching = true
        viewModelScope.launch {
            try {
                val r = withContext(Dispatchers.IO) { fetchWeather() }
                if (r != null) {
                    lastFetch = SystemClock.elapsedRealtime()
                    _state.update {
                        it.copy(tempC = r.tempC, emoji = r.emoji, description = r.description, city = r.city)
                    }
                }
            } catch (e: Exception) {
                // keep the previous value; retried automatically
            } finally {
                fetching = false
            }
        }
    }

    private data class Place(val lat: Double, val lon: Double, val city: String)

    private fun fetchWeather(): WeatherState? {
        val place = locate() ?: return null
        val url = "https://api.open-meteo.com/v1/forecast?latitude=${place.lat}&longitude=${place.lon}" +
            "&current=temperature_2m,weather_code"
        val cur = JSONObject(httpGet(url)).getJSONObject("current")
        val temp = cur.getDouble("temperature_2m").roundToInt()
        val (emoji, desc) = describe(cur.getInt("weather_code"))
        return WeatherState(online = true, tempC = temp, emoji = emoji, description = desc, city = place.city)
    }

    private fun locate(): Place? {
        if (ctx.hasLocationPermission()) {
            try {
                val lm = ctx.getSystemService(LocationManager::class.java)
                val loc = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
                    .mapNotNull { p -> runCatching { lm.getLastKnownLocation(p) }.getOrNull() }
                    .maxByOrNull { it.time }
                if (loc != null) return Place(loc.latitude, loc.longitude, cityFor(loc.latitude, loc.longitude))
            } catch (e: Exception) { /* fall through to IP lookup */ }
        }
        return try {
            val j = JSONObject(httpGet("https://ipwho.is/"))
            if (j.optBoolean("success", true)) {
                Place(j.getDouble("latitude"), j.getDouble("longitude"), j.optString("city"))
            } else null
        } catch (e: Exception) { null }
    }

    @Suppress("DEPRECATION")
    private fun cityFor(lat: Double, lon: Double): String {
        try {
            if (Geocoder.isPresent()) {
                val ad = Geocoder(ctx, Locale.getDefault()).getFromLocation(lat, lon, 1)?.firstOrNull()
                val c = ad?.locality ?: ad?.subAdminArea ?: ad?.adminArea
                if (!c.isNullOrBlank()) return c
            }
        } catch (e: Exception) { /* try web fallback */ }
        return try {
            val j = JSONObject(
                httpGet("https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=$lat&longitude=$lon&localityLanguage=en")
            )
            j.optString("city").ifBlank { j.optString("locality") }
        } catch (e: Exception) { "" }
    }

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "OSLauncher/2.0")
        return try {
            c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun describe(code: Int): Pair<String, String> = when (code) {
        0 -> "☀️" to "Clear"
        1, 2 -> "🌤️" to "Partly cloudy"
        3 -> "☁️" to "Cloudy"
        45, 48 -> "🌫️" to "Fog"
        51, 53, 55, 56, 57 -> "🌦️" to "Drizzle"
        61, 63, 65, 66, 67, 80, 81, 82 -> "🌧️" to "Rain"
        71, 73, 75, 77, 85, 86 -> "❄️" to "Snow"
        95, 96, 99 -> "⛈️" to "Thunderstorm"
        else -> "🌡️" to "Weather"
    }

    override fun onCleared() {
        runCatching { cm.unregisterNetworkCallback(callback) }
        super.onCleared()
    }
}
