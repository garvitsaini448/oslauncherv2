package com.example.oslauncher

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

class HomeActions(
    val onLaunch: (AppEntry) -> Unit,
    val onUninstall: (AppEntry) -> Unit,
    val onInfo: (AppEntry) -> Unit,
    val onRestore: () -> Unit,
    val onRequestPermissions: () -> Unit,
    val onAllFilesAccess: () -> Unit,
    val onOpenMedia: (MediaHit) -> Unit,
    val onWebSearch: (String) -> Unit,
    val onYoutubeSearch: (String) -> Unit
)

@Composable
fun HomeScreen(
    statusVm: StatusViewModel,
    appsVm: AppsViewModel,
    musicVm: MusicViewModel,
    weatherVm: WeatherViewModel,
    settingsVm: SettingsViewModel,
    searchVm: SearchViewModel,
    homeTick: Int,
    actions: HomeActions
) {
    val status by statusVm.state.collectAsStateWithLifecycle()
    val apps by appsVm.apps.collectAsStateWithLifecycle()
    val player by musicVm.state.collectAsStateWithLifecycle()
    val weather by weatherVm.state.collectAsStateWithLifecycle()
    val settings by settingsVm.settings.collectAsStateWithLifecycle()
    val query by searchVm.query.collectAsStateWithLifecycle()
    val media by searchVm.media.collectAsStateWithLifecycle()

    var drawerOpen by remember { mutableStateOf(false) }
    var folder by remember { mutableStateOf<AppCategory?>(null) }
    var settingsOpen by remember { mutableStateOf(false) }
    var songsOpen by remember { mutableStateOf(false) }
    var menuApp by remember { mutableStateOf<AppEntry?>(null) }

    val searching = query.isNotBlank()
    val focusManager = LocalFocusManager.current
    val listState = rememberLazyListState()

    val grouped = remember(apps) { apps.groupBy { it.category } }
    val pinnedApps = remember(apps, settings.pinned) {
        settings.pinned.mapNotNull { pkg -> apps.firstOrNull { it.packageName == pkg } }
    }

    // Pressing Home again resets everything to the clean home screen
    LaunchedEffect(homeTick) {
        if (homeTick > 0) {
            drawerOpen = false
            folder = null
            searchVm.setQuery("")
            focusManager.clearFocus()
            listState.animateScrollToItem(0)
        }
    }

    BackHandler(enabled = drawerOpen || searching) {
        if (drawerOpen) drawerOpen = false
        else { searchVm.setQuery(""); focusManager.clearFocus() }
    }

    val launch: (AppEntry) -> Unit = {
        searchVm.setQuery("")
        drawerOpen = false
        folder = null
        focusManager.clearFocus()
        actions.onLaunch(it)
    }
    val longPress: (AppEntry) -> Unit = { menuApp = it }

    // Swipe up past the end of the home list -> open the app drawer
    val swipeUp = remember {
        object : NestedScrollConnection {
            var pulled = 0f
            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (source == NestedScrollSource.Drag) {
                    if (available.y < 0f) {
                        pulled += available.y
                        if (pulled < -140f) { pulled = 0f; drawerOpen = true }
                    } else pulled = 0f
                }
                return Offset.Zero
            }
            override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                pulled = 0f
                return Velocity.Zero
            }
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xB3070C16), Color(0xE60B1220))))
    ) {
        // ------------------------------------------------------------ home content
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize().statusBarsPadding().nestedScroll(swipeUp),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 150.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                StatusWidget(status, weather, settings.showWeather, onSecretGesture = { settingsOpen = true })
            }
            item {
                MusicWidget(
                    p = player,
                    onToggle = musicVm::toggle,
                    onNext = musicVm::next,
                    onPrev = musicVm::previous,
                    onSeek = musicVm::seekTo,
                    onOpenLibrary = { songsOpen = true },
                    onRequestPermission = actions.onRequestPermissions
                )
            }
            item { SectionTitle("Folders") }
            item { FolderTiles(grouped, settings.liveTiles) { folder = it } }
            if (pinnedApps.isNotEmpty()) {
                item { SectionTitle("Pinned") }
                item { PinnedTiles(pinnedApps, launch, longPress) }
            }
        }

        // ----------------------------------------- bottom: handle + universal search
        // One stable Column so the text field keeps focus while results appear.
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()
        ) {
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .then(if (searching) Modifier.background(Color(0xF0080D16)) else Modifier)
            ) {
                if (searching) {
                    SearchResults(
                        query = query,
                        apps = apps,
                        songs = player.songs,
                        media = media,
                        onApp = launch,
                        onAppLong = longPress,
                        onSong = { musicVm.play(it); searchVm.setQuery(""); focusManager.clearFocus() },
                        onMedia = { actions.onOpenMedia(it) },
                        onWeb = actions.onWebSearch,
                        onYoutube = actions.onYoutubeSearch,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
            if (!searching) {
                DrawerHandle(onOpen = { drawerOpen = true })
            }
            UniversalSearchBar(
                query = query,
                onQuery = searchVm::setQuery,
                onSubmit = { if (query.isNotBlank()) actions.onWebSearch(query.trim()) },
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
            )
        }

        // --------------------------------------------------------------- app drawer
        AnimatedVisibility(
            visible = drawerOpen,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut()
        ) {
            AppDrawer(
                apps = apps,
                onClose = { drawerOpen = false },
                onLaunch = launch,
                onLongPress = longPress,
                onSettings = { settingsOpen = true }
            )
        }
    }

    // ------------------------------------------------------------------ dialogs
    folder?.let { cat ->
        FolderDialog(cat, grouped[cat].orEmpty(), onDismiss = { folder = null }, onLaunch = launch, onLongPress = longPress)
    }

    menuApp?.let { app ->
        AppMenuDialog(
            app = app,
            pinned = app.packageName in settings.pinned,
            onDismiss = { menuApp = null },
            onInfo = { menuApp = null; actions.onInfo(app) },
            onPin = { settingsVm.togglePin(app.packageName); menuApp = null },
            onUninstall = { menuApp = null; actions.onUninstall(app) }
        )
    }

    if (songsOpen) {
        SongLibraryDialog(
            songs = player.songs,
            currentId = player.current?.id,
            onPick = musicVm::play,
            onDismiss = { songsOpen = false }
        )
    }

    if (settingsOpen) {
        SettingsDialog(
            settings = settings,
            onShowWeather = settingsVm::setShowWeather,
            onLiveTiles = settingsVm::setLiveTiles,
            onPermissions = actions.onRequestPermissions,
            onAllFiles = actions.onAllFilesAccess,
            onClearPins = settingsVm::clearPins,
            onRestore = { settingsOpen = false; actions.onRestore() },
            onDismiss = { settingsOpen = false }
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text.uppercase(), color = Color(0xB3FFFFFF), fontSize = 12.sp,
        fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, top = 4.dp)
    )
}

@Composable
private fun DrawerHandle(onOpen: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { total = 0f }
                ) { _, dy ->
                    total += dy
                    if (total < -60f) { total = 0f; onOpen() }
                }
            }
            .clickable(onClick = onOpen)
            .padding(top = 6.dp, bottom = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.width(44.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color(0x88FFFFFF)))
        Text("Swipe up for all apps", color = Color(0x88FFFFFF), fontSize = 10.sp, modifier = Modifier.padding(top = 3.dp))
    }
}
