package com.example.oslauncher

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

val NeonGreen = Color(0xFF00E676)
val NeonRed = Color(0xFFFF1744)
val NeonBlue = Color(0xFF40C4FF)
val NeonCyan = Color(0xFF00E5FF)
val IdleGray = Color(0xFF607D8B)

private fun DrawScope.glowArc(color: Color, center: Offset, r: Float, start: Float, sweep: Float, sw: Float) {
    val tl = Offset(center.x - r, center.y - r)
    val sz = Size(r * 2f, r * 2f)
    drawArc(color.copy(alpha = 0.25f), start, sweep, false, tl, sz, style = Stroke(sw * 2.4f, cap = StrokeCap.Round))
    drawArc(color, start, sweep, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
}

private fun DrawScope.glowDot(color: Color, center: Offset, r: Float) {
    drawCircle(color.copy(alpha = 0.25f), r * 1.9f, center)
    drawCircle(color, r, center)
}

@Composable
fun WifiGlyph(color: Color, modifier: Modifier = Modifier.size(26.dp)) {
    Canvas(modifier) {
        val w = size.width
        val c = Offset(w / 2f, size.height * 0.86f)
        val sw = w * 0.09f
        listOf(0.68f, 0.46f, 0.24f).forEach { f -> glowArc(color, c, w * f, 225f, 90f, sw) }
        glowDot(color, c, sw * 1.1f)
    }
}

@Composable
fun HotspotGlyph(color: Color, modifier: Modifier = Modifier.size(26.dp)) {
    Canvas(modifier) {
        val w = size.width
        val c = Offset(w / 2f, size.height / 2f)
        val sw = w * 0.09f
        listOf(0.22f, 0.38f).forEach { f ->
            glowArc(color, c, w * f, -40f, 80f, sw)
            glowArc(color, c, w * f, 140f, 80f, sw)
        }
        glowDot(color, c, w * 0.09f)
    }
}

@Composable
fun BluetoothGlyph(color: Color, modifier: Modifier = Modifier.size(22.dp)) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val p = Path().apply {
            moveTo(w * 0.25f, h * 0.30f)
            lineTo(w * 0.75f, h * 0.70f)
            lineTo(w * 0.50f, h * 0.92f)
            lineTo(w * 0.50f, h * 0.08f)
            lineTo(w * 0.75f, h * 0.30f)
            lineTo(w * 0.25f, h * 0.70f)
        }
        drawPath(p, color.copy(alpha = 0.25f), style = Stroke(w * 0.22f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawPath(p, color, style = Stroke(w * 0.09f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
fun PlayGlyph(color: Color, modifier: Modifier = Modifier.size(28.dp)) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val p = Path().apply {
            moveTo(w * 0.28f, h * 0.18f)
            lineTo(w * 0.82f, h * 0.50f)
            lineTo(w * 0.28f, h * 0.82f)
            close()
        }
        drawPath(p, color)
    }
}

@Composable
fun PauseGlyph(color: Color, modifier: Modifier = Modifier.size(28.dp)) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        drawRect(color, Offset(w * 0.22f, h * 0.18f), Size(w * 0.20f, h * 0.64f))
        drawRect(color, Offset(w * 0.58f, h * 0.18f), Size(w * 0.20f, h * 0.64f))
    }
}

@Composable
fun SkipGlyph(color: Color, forward: Boolean, modifier: Modifier = Modifier.size(24.dp)) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        fun fx(x: Float) = if (forward) x * w else (1f - x) * w
        val tri = Path().apply {
            moveTo(fx(0.18f), h * 0.20f)
            lineTo(fx(0.68f), h * 0.50f)
            lineTo(fx(0.18f), h * 0.80f)
            close()
        }
        drawPath(tri, color)
        val left = minOf(fx(0.74f), fx(0.84f))
        drawRect(color, Offset(left, h * 0.20f), Size(w * 0.10f, h * 0.60f))
    }
}

@Composable
fun SearchGlyph(color: Color, modifier: Modifier = Modifier.size(20.dp)) {
    Canvas(modifier) {
        val w = size.width
        val sw = w * 0.11f
        drawCircle(color, w * 0.30f, Offset(w * 0.42f, w * 0.42f), style = Stroke(sw))
        drawLine(color, Offset(w * 0.64f, w * 0.64f), Offset(w * 0.92f, w * 0.92f), sw, StrokeCap.Round)
    }
}

@Composable
fun CloseGlyph(color: Color, modifier: Modifier = Modifier.size(18.dp)) {
    Canvas(modifier) {
        val w = size.width
        val sw = w * 0.12f
        drawLine(color, Offset(w * 0.2f, w * 0.2f), Offset(w * 0.8f, w * 0.8f), sw, StrokeCap.Round)
        drawLine(color, Offset(w * 0.8f, w * 0.2f), Offset(w * 0.2f, w * 0.8f), sw, StrokeCap.Round)
    }
}

@Composable
fun SettingsGlyph(color: Color, modifier: Modifier = Modifier.size(22.dp)) {
    Canvas(modifier) {
        val w = size.width
        val sw = w * 0.08f
        listOf(0.25f to 0.68f, 0.50f to 0.32f, 0.75f to 0.62f).forEach { (y, kx) ->
            drawLine(color, Offset(w * 0.1f, w * y), Offset(w * 0.9f, w * y), sw, StrokeCap.Round)
            drawCircle(color, w * 0.10f, Offset(w * kx, w * y))
        }
    }
}
