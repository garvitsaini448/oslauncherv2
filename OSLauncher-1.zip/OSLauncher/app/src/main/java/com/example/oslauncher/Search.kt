package com.example.oslauncher

import android.app.Application
import android.content.ContentResolver
import android.content.ContentUris
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.mapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.withContext

data class MediaHit(
    val title: String,
    val subtitle: String,
    val uri: Uri,
    val mime: String,
    val emoji: String
)

data class MediaResults(
    val videos: List<MediaHit> = emptyList(),
    val files: List<MediaHit> = emptyList()
)

@OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
class SearchViewModel(application: Application) : AndroidViewModel(application) {

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()
    fun setQuery(q: String) { _query.value = q }

    val media: StateFlow<MediaResults> = _query
        .debounce(250)
        .mapLatest { q ->
            val t = q.trim()
            if (t.length < 2) MediaResults()
            else withContext(Dispatchers.IO) { runCatching { searchMedia(t) }.getOrDefault(MediaResults()) }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), MediaResults())

    private fun searchMedia(q: String): MediaResults {
        val videos = queryTable(
            uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            nameCol = MediaStore.Video.Media.DISPLAY_NAME,
            mimeCol = MediaStore.Video.Media.MIME_TYPE,
            extraSel = null, like = q, emoji = "🎬", appendId = true
        )
        val files = queryTable(
            uri = MediaStore.Files.getContentUri("external"),
            nameCol = MediaStore.Files.FileColumns.DISPLAY_NAME,
            mimeCol = MediaStore.Files.FileColumns.MIME_TYPE,
            extraSel = "${MediaStore.Files.FileColumns.MEDIA_TYPE} NOT IN (2,3) AND " +
                "${MediaStore.Files.FileColumns.MIME_TYPE} IS NOT NULL",
            like = q, emoji = "📄", appendId = true
        )
        return MediaResults(videos, files)
    }

    private fun queryTable(
        uri: Uri, nameCol: String, mimeCol: String, extraSel: String?,
        like: String, emoji: String, appendId: Boolean
    ): List<MediaHit> {
        val out = ArrayList<MediaHit>()
        val proj = arrayOf(MediaStore.MediaColumns._ID, nameCol, mimeCol)
        val sel = "$nameCol LIKE ?" + (extraSel?.let { " AND $it" } ?: "")
        val args = Bundle().apply {
            putString(ContentResolver.QUERY_ARG_SQL_SELECTION, sel)
            putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, arrayOf("%$like%"))
            putInt(ContentResolver.QUERY_ARG_LIMIT, 15)
        }
        getApplication<Application>().contentResolver.query(uri, proj, args, null)?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val iName = c.getColumnIndexOrThrow(nameCol)
            val iMime = c.getColumnIndexOrThrow(mimeCol)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val mime = c.getString(iMime).orEmpty()
                out.add(
                    MediaHit(
                        title = c.getString(iName).orEmpty(),
                        subtitle = mime,
                        uri = if (appendId) ContentUris.withAppendedId(uri, id) else uri,
                        mime = mime,
                        emoji = emoji
                    )
                )
            }
        }
        return out
    }
}
