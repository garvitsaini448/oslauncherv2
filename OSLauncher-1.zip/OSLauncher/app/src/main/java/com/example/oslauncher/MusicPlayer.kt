package com.example.oslauncher

import android.app.Application
import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Size
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val albumId: Long,
    val durationMs: Long,
    val uri: Uri
)

data class PlayerState(
    val songs: List<Song> = emptyList(),
    val index: Int = -1,
    val isPlaying: Boolean = false,
    val positionMs: Int = 0,
    val durationMs: Int = 0,
    val art: ImageBitmap? = null,
    val hasPermission: Boolean = true
) {
    val current: Song? get() = songs.getOrNull(index)
}

class MusicController(private val app: Application) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val _state = MutableStateFlow(PlayerState())
    val state: StateFlow<PlayerState> = _state.asStateFlow()

    private var player: MediaPlayer? = null
    private var prepared = false
    private var wantPlay = false
    private var ticker: Job? = null
    private var lastLoad = 0L

    private val audioManager: AudioManager = app.getSystemService(AudioManager::class.java)
    private var focusRequest: AudioFocusRequest? = null
    private val attrs = AudioAttributes.Builder()
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .build()

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) pause()
    }

    // ---------------------------------------------------------------- library

    fun loadLibrary(force: Boolean = false) {
        if (!app.hasMediaPermission()) {
            _state.update { it.copy(hasPermission = false) }
            return
        }
        val now = SystemClock.elapsedRealtime()
        if (!force && _state.value.songs.isNotEmpty() && now - lastLoad < 60_000L) return
        lastLoad = now
        scope.launch {
            val list = withContext(Dispatchers.IO) { runCatching { queryAudio() }.getOrDefault(emptyList()) }
            val currentId = _state.value.current?.id
            val remapped = list.indexOfFirst { it.id == currentId }
            _state.update { it.copy(songs = list, hasPermission = true, index = if (remapped >= 0) remapped else it.index) }
            if (remapped < 0 && player == null && list.isNotEmpty()) prepare(0, autoPlay = false)
        }
    }

    private fun queryAudio(): List<Song> {
        val out = ArrayList<Song>()
        val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM_ID, MediaStore.Audio.Media.DURATION
        )
        val sel = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 30000"
        app.contentResolver.query(base, proj, sel, null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val artist = c.getString(iArtist).orEmpty()
                out.add(
                    Song(
                        id = id,
                        title = c.getString(iTitle).orEmpty().ifBlank { "Unknown" },
                        artist = if (artist == "<unknown>") "Unknown artist" else artist,
                        albumId = c.getLong(iAlbum),
                        durationMs = c.getLong(iDur),
                        uri = ContentUris.withAppendedId(base, id)
                    )
                )
            }
        }
        return out
    }

    // --------------------------------------------------------------- controls

    fun playSong(song: Song) {
        val i = _state.value.songs.indexOfFirst { it.id == song.id }
        if (i >= 0) prepare(i, autoPlay = true)
    }

    fun toggle() {
        val s = _state.value
        if (player == null) {
            if (s.songs.isNotEmpty()) prepare(s.index.coerceAtLeast(0), autoPlay = true)
            return
        }
        if (s.isPlaying) pause() else startPlayback()
    }

    fun next() {
        val s = _state.value
        if (s.songs.isEmpty()) return
        prepare((s.index + 1).mod(s.songs.size), autoPlay = true)
    }

    fun previous() {
        val s = _state.value
        if (s.songs.isEmpty()) return
        if (s.positionMs > 3000) seekTo(0) else prepare((s.index - 1).mod(s.songs.size), autoPlay = true)
    }

    fun seekTo(ms: Int) {
        try { if (prepared) player?.seekTo(ms) } catch (e: IllegalStateException) { }
        _state.update { it.copy(positionMs = ms) }
    }

    fun pause() {
        try { player?.pause() } catch (e: IllegalStateException) { }
        wantPlay = false
        ticker?.cancel()
        _state.update { it.copy(isPlaying = false) }
        abandonFocus()
    }

    // --------------------------------------------------------------- internals

    private fun prepare(index: Int, autoPlay: Boolean) {
        val song = _state.value.songs.getOrNull(index) ?: return
        releasePlayer()
        wantPlay = autoPlay
        _state.update {
            it.copy(index = index, isPlaying = false, positionMs = 0, durationMs = song.durationMs.toInt(), art = null)
        }
        loadArt(song)
        val mp = MediaPlayer()
        player = mp
        try {
            mp.setAudioAttributes(attrs)
            mp.setWakeMode(app, PowerManager.PARTIAL_WAKE_LOCK)
            mp.setDataSource(app, song.uri)
            mp.setOnPreparedListener { p ->
                prepared = true
                _state.update { it.copy(durationMs = p.duration) }
                if (wantPlay) startPlayback()
            }
            mp.setOnCompletionListener { next() }
            mp.setOnErrorListener { _, _, _ ->
                prepared = false
                _state.update { it.copy(isPlaying = false) }
                true
            }
            mp.prepareAsync()
        } catch (e: Exception) {
            _state.update { it.copy(isPlaying = false) }
        }
    }

    private fun startPlayback() {
        val p = player ?: return
        if (!prepared) { wantPlay = true; return }
        if (!requestFocus()) return
        try { p.start() } catch (e: IllegalStateException) { return }
        _state.update { it.copy(isPlaying = true) }
        startTicker()
    }

    private fun startTicker() {
        ticker?.cancel()
        ticker = scope.launch {
            while (isActive) {
                val p = player
                if (p != null && prepared) {
                    try {
                        val pos = p.currentPosition
                        _state.update { it.copy(positionMs = pos) }
                    } catch (e: IllegalStateException) { }
                }
                delay(500)
            }
        }
    }

    private fun releasePlayer() {
        ticker?.cancel()
        prepared = false
        player?.let { runCatching { it.release() } }
        player = null
    }

    private fun requestFocus(): Boolean {
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(attrs)
            .setOnAudioFocusChangeListener(focusListener)
            .build()
        focusRequest = req
        return audioManager.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun abandonFocus() {
        focusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
    }

    private fun loadArt(song: Song) {
        scope.launch {
            val bmp: Bitmap? = withContext(Dispatchers.IO) {
                try {
                    if (Build.VERSION.SDK_INT >= 29) {
                        app.contentResolver.loadThumbnail(song.uri, Size(512, 512), null)
                    } else {
                        val u = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), song.albumId)
                        app.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it) }
                    }
                } catch (e: Exception) { null }
            }
            if (_state.value.current?.id == song.id) _state.update { it.copy(art = bmp?.asImageBitmap()) }
        }
    }
}

class MusicViewModel(application: Application) : AndroidViewModel(application) {
    private val controller: MusicController = (application as LauncherApp).music
    val state: StateFlow<PlayerState> = controller.state

    fun load(force: Boolean = false) = controller.loadLibrary(force)
    fun toggle() = controller.toggle()
    fun next() = controller.next()
    fun previous() = controller.previous()
    fun seekTo(ms: Int) = controller.seekTo(ms)
    fun play(song: Song) = controller.playSong(song)
}
