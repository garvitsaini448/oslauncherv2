package com.example.oslauncher

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color as AColor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

class MainActivity : ComponentActivity() {

    private val statusVm: StatusViewModel by viewModels()
    private val appsVm: AppsViewModel by viewModels()
    private val musicVm: MusicViewModel by viewModels()
    private val weatherVm: WeatherViewModel by viewModels()
    private val settingsVm: SettingsViewModel by viewModels()
    private val searchVm: SearchViewModel by viewModels()

    private var homeTick by mutableIntStateOf(0)

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            musicVm.load(force = true)
            weatherVm.refresh(force = true)
            if (!hasMediaPermission()) {
                toast("Media access denied. Enable it in App Info > Permissions to use music & search.")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )

        // Pressing the Home button while the launcher is already open
        addOnNewIntentListener { homeTick++ }

        if (!settingsVm.permissionsAsked) {
            settingsVm.markPermissionsAsked()
            permissionLauncher.launch(runtimePermissions())
        }

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                BackHandler(enabled = true) { }   // a launcher never "goes back" out of itself

                val actions = remember {
                    HomeActions(
                        onLaunch = ::launchApp,
                        onUninstall = ::uninstallApp,
                        onInfo = ::openAppInfo,
                        onRestore = ::restoreDefaultLauncher,
                        onRequestPermissions = { permissionLauncher.launch(runtimePermissions()) },
                        onAllFilesAccess = ::openAllFilesAccess,
                        onOpenMedia = ::openMedia,
                        onWebSearch = ::webSearch,
                        onYoutubeSearch = ::youtubeSearch
                    )
                }
                HomeScreen(
                    statusVm = statusVm,
                    appsVm = appsVm,
                    musicVm = musicVm,
                    weatherVm = weatherVm,
                    settingsVm = settingsVm,
                    searchVm = searchVm,
                    homeTick = homeTick,
                    actions = actions
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        musicVm.load(force = false)
        weatherVm.refresh(force = false)
    }

    private fun launchApp(app: AppEntry) {
        val intent = packageManager.getLaunchIntentForPackage(app.packageName)
        if (intent == null) {
            toast("Cannot open ${app.label}")
            return
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        safeStart(intent)
    }

    private fun uninstallApp(app: AppEntry) {
        if (!app.canUninstall) {
            toast("${app.label} is a system app and can't be uninstalled")
            return
        }
        safeStart(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}")))
    }

    private fun openAppInfo(app: AppEntry) {
        safeStart(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}")))
    }

    private fun restoreDefaultLauncher() {
        try {
            startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        } catch (e: ActivityNotFoundException) {
            safeStart(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun openAllFilesAccess() {
        if (Build.VERSION.SDK_INT < 30) {
            toast("Not needed on this Android version")
            return
        }
        try {
            startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            safeStart(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
        }
    }

    private fun openMedia(hit: MediaHit) {
        val i = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(hit.uri, hit.mime.ifBlank { "*/*" })
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        safeStart(i)
    }

    private fun webSearch(q: String) =
        safeStart(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${Uri.encode(q)}")))

    private fun youtubeSearch(q: String) =
        safeStart(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(q)}")))

    private fun safeStart(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: Exception) {
            toast("Action not available on this device")
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
