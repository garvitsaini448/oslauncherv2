package com.example.oslauncher

import android.app.Application

/** Application-scoped holder so music keeps playing even if the Activity is recreated. */
class LauncherApp : Application() {
    val music: MusicController by lazy { MusicController(this) }
}
