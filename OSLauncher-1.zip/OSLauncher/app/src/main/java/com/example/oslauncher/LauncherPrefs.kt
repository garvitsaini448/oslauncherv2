package com.example.oslauncher

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class LauncherSettings(
    val showWeather: Boolean = true,
    val liveTiles: Boolean = true,
    val pinned: List<String> = emptyList()
)

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("launcher_prefs", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(
        LauncherSettings(
            showWeather = prefs.getBoolean("show_weather", true),
            liveTiles = prefs.getBoolean("live_tiles", true),
            pinned = prefs.getString("pinned", "").orEmpty().split("|").filter { it.isNotBlank() }
        )
    )
    val settings: StateFlow<LauncherSettings> = _settings.asStateFlow()

    val permissionsAsked: Boolean get() = prefs.getBoolean("perms_asked", false)
    fun markPermissionsAsked() = prefs.edit().putBoolean("perms_asked", true).apply()

    fun setShowWeather(v: Boolean) {
        prefs.edit().putBoolean("show_weather", v).apply()
        _settings.update { it.copy(showWeather = v) }
    }

    fun setLiveTiles(v: Boolean) {
        prefs.edit().putBoolean("live_tiles", v).apply()
        _settings.update { it.copy(liveTiles = v) }
    }

    fun togglePin(pkg: String) {
        val cur = _settings.value.pinned
        savePins(if (pkg in cur) cur - pkg else cur + pkg)
    }

    fun clearPins() = savePins(emptyList())

    private fun savePins(list: List<String>) {
        prefs.edit().putString("pinned", list.joinToString("|")).apply()
        _settings.update { it.copy(pinned = list) }
    }
}
