package com.example.oslauncher

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import androidx.core.content.ContextCompat

fun runtimePermissions(): Array<String> =
    if (Build.VERSION.SDK_INT >= 33) arrayOf(
        Manifest.permission.ACCESS_COARSE_LOCATION,
        Manifest.permission.READ_MEDIA_AUDIO,
        Manifest.permission.READ_MEDIA_VIDEO,
        Manifest.permission.READ_MEDIA_IMAGES
    ) else arrayOf(
        Manifest.permission.ACCESS_COARSE_LOCATION,
        Manifest.permission.READ_EXTERNAL_STORAGE
    )

private fun Context.granted(p: String): Boolean =
    ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

fun Context.hasMediaPermission(): Boolean =
    if (Build.VERSION.SDK_INT >= 33) granted(Manifest.permission.READ_MEDIA_AUDIO)
    else granted(Manifest.permission.READ_EXTERNAL_STORAGE)

fun Context.hasLocationPermission(): Boolean = granted(Manifest.permission.ACCESS_COARSE_LOCATION)

fun hasAllFilesAccess(): Boolean =
    Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()
